var structlibecs_1_1DeletePtr =
[
    [ "argument_type", "structlibecs_1_1DeletePtr.html#a0e5cb8dadd5235ac4946fa15db4e2528", null ],
    [ "result_type", "structlibecs_1_1DeletePtr.html#ae2305d2e4c8abd7d83529827b02f403b", null ],
    [ "operator()", "structlibecs_1_1DeletePtr.html#ab0927cf35c76f1623ec44d21231bf164", null ]
];