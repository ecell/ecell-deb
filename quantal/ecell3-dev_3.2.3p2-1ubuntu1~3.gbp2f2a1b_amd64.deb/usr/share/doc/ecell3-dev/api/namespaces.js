var namespaces =
[
    [ "libecs", "namespacelibecs.html", null ]
];