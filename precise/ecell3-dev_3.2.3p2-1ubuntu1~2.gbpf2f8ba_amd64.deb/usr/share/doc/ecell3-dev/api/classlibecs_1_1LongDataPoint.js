var classlibecs_1_1LongDataPoint =
[
    [ "LongDataPoint", "classlibecs_1_1LongDataPoint.html#a6e749c488327da6bd42d503aff6a608a", null ],
    [ "LongDataPoint", "classlibecs_1_1LongDataPoint.html#a682cc9af93b6d2d8322dc9292a54be65", null ],
    [ "LongDataPoint", "classlibecs_1_1LongDataPoint.html#a02eba1f8794ce9f5f4225078b3b12efb", null ],
    [ "LongDataPoint", "classlibecs_1_1LongDataPoint.html#af41bfd7573a2c0bb2d1a8460dba66341", null ],
    [ "~LongDataPoint", "classlibecs_1_1LongDataPoint.html#acb83519d4adcaa3cf920e3269c0cdf1d", null ],
    [ "getAvg", "classlibecs_1_1LongDataPoint.html#a8c2b6a470a8c91405aa2efa1fc786875", null ],
    [ "getElementNumber", "classlibecs_1_1LongDataPoint.html#a440798e7991567510c31e0dd91a9196d", null ],
    [ "getElementSize", "classlibecs_1_1LongDataPoint.html#a5725317aec190176921421701552fdf1", null ],
    [ "getMax", "classlibecs_1_1LongDataPoint.html#a8c11bffda44fa331d443a2988206a486", null ],
    [ "getMin", "classlibecs_1_1LongDataPoint.html#aea64a42a09fb39ec01fe02d0d8e5e1e2", null ],
    [ "getTime", "classlibecs_1_1LongDataPoint.html#a9240a7b30c36849c669c9735fce81b9a", null ],
    [ "getValue", "classlibecs_1_1LongDataPoint.html#a073e92cfc580126af0407ba9429f9e86", null ],
    [ "setAvg", "classlibecs_1_1LongDataPoint.html#a07062a185d1a9d04407763013c903ade", null ],
    [ "setMax", "classlibecs_1_1LongDataPoint.html#a6a08fa3ac71a79852e2b0197b4d6530b", null ],
    [ "setMin", "classlibecs_1_1LongDataPoint.html#a770fb4d8818df3cbf7ca844627dcb530", null ],
    [ "setTime", "classlibecs_1_1LongDataPoint.html#a71ef42615cffc336b69a563eab6089e2", null ],
    [ "setValue", "classlibecs_1_1LongDataPoint.html#aba4d8026b6d30f3a68bcafcede16a8a5", null ],
    [ "theAvg", "classlibecs_1_1LongDataPoint.html#a8ed50ec9c371e2dbd5e579c424d20728", null ],
    [ "theMax", "classlibecs_1_1LongDataPoint.html#a85be4e053f71603545dba230b8fe0350", null ],
    [ "theMin", "classlibecs_1_1LongDataPoint.html#aca8a04e4ba3dbbdd4b38a22746bcfa22", null ]
];