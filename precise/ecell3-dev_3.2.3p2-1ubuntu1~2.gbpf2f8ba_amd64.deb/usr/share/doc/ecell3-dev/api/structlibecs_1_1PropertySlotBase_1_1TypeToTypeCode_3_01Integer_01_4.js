var structlibecs_1_1PropertySlotBase_1_1TypeToTypeCode_3_01Integer_01_4 =
[
    [ "value", "structlibecs_1_1PropertySlotBase_1_1TypeToTypeCode_3_01Integer_01_4.html#a748426814a16ddecf4f43afb1c0398a7", null ]
];