var classlibecs_1_1DataPoint_1_1EarlinessOrdering =
[
    [ "operator()", "classlibecs_1_1DataPoint_1_1EarlinessOrdering.html#a2d3cf7879de089718f2fb7253a436444", null ]
];