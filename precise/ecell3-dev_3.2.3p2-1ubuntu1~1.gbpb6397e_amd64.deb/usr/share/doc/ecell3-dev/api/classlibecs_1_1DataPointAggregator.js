var classlibecs_1_1DataPointAggregator =
[
    [ "DataPointAggregator", "classlibecs_1_1DataPointAggregator.html#ab33f1340bf151849a29d4cb92197f593", null ],
    [ "DataPointAggregator", "classlibecs_1_1DataPointAggregator.html#a24a411ef358a9334d26f355c993b02af", null ],
    [ "~DataPointAggregator", "classlibecs_1_1DataPointAggregator.html#a47dc8aa9370d26857e7531d8f314ed28", null ],
    [ "aggregate", "classlibecs_1_1DataPointAggregator.html#ad6799d345f29edba36a4f667eae648e3", null ],
    [ "beginNextPoint", "classlibecs_1_1DataPointAggregator.html#ae4c9feb09500a17ff29ce9c393103155", null ],
    [ "getData", "classlibecs_1_1DataPointAggregator.html#a180db75bfa4c0dbf8dfdecb8540a027a", null ],
    [ "getLastPoint", "classlibecs_1_1DataPointAggregator.html#a449747e9cac321309eedb1773a9f3c4c", null ]
];