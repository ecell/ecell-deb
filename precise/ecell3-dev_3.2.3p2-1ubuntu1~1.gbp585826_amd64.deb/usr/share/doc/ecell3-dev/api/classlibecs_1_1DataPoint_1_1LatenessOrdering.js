var classlibecs_1_1DataPoint_1_1LatenessOrdering =
[
    [ "operator()", "classlibecs_1_1DataPoint_1_1LatenessOrdering.html#a01ec59c4a342eb32043ccdd74ef370a2", null ]
];