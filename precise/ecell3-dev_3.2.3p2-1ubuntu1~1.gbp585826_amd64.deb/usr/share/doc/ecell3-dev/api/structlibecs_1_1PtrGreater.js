var structlibecs_1_1PtrGreater =
[
    [ "operator()", "structlibecs_1_1PtrGreater.html#a99b1d4960aa5443c7a98809522706d14", null ]
];