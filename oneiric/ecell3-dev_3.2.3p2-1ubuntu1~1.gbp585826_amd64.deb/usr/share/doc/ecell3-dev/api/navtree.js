var NAVTREE =
[
  [ "E-CELL C++ libraries (libecs and libemc) 3.2.3pre2", "index.html", [
    [ "Related Pages", "pages.html", [
      [ "Deprecated List", "deprecated.html", null ]
    ] ],
    [ "Class List", "annotated.html", [
      [ "libecs::scripting::Assembler", "classlibecs_1_1scripting_1_1Assembler.html", null ],
      [ "Loki::AssocVector< K, V, C, A >", "classLoki_1_1AssocVector.html", null ],
      [ "Loki::Private::AssocVectorCompare< Value, C >", "classLoki_1_1Private_1_1AssocVectorCompare.html", null ],
      [ "C", "classC.html", null ],
      [ "libecs::VariableReference::CoefficientLess", "classlibecs_1_1VariableReference_1_1CoefficientLess.html", null ],
      [ "libecs::ConcretePropertySlot< T, SlotType_ >", "classlibecs_1_1ConcretePropertySlot.html", null ],
      [ "libecs::ConcretePropertySlotProxy< T >", "classlibecs_1_1ConcretePropertySlotProxy.html", null ],
      [ "libecs::LoggerBroker::const_iterator", "structlibecs_1_1LoggerBroker_1_1const__iterator.html", null ],
      [ "libecs::ConvertTo< ToType, FromType >", "classlibecs_1_1ConvertTo.html", null ],
      [ "libecs::ConvertTo< String, FromType >", "classlibecs_1_1ConvertTo_3_01String_00_01FromType_01_4.html", null ],
      [ "libecs::ConvertTo< String, Polymorph >", "classlibecs_1_1ConvertTo_3_01String_00_01Polymorph_01_4.html", null ],
      [ "libecs::ConvertTo< String, String >", "classlibecs_1_1ConvertTo_3_01String_00_01String_01_4.html", null ],
      [ "libecs::ConvertTo< Tnew_, Polymorph >", "classlibecs_1_1ConvertTo_3_01Tnew___00_01Polymorph_01_4.html", null ],
      [ "libecs::ConvertTo< ToType, char * >", "classlibecs_1_1ConvertTo_3_01ToType_00_01char_01_5_01_4.html", null ],
      [ "libecs::ConvertTo< ToType, char const * >", "classlibecs_1_1ConvertTo_3_01ToType_00_01char_01const_01_5_01_4.html", null ],
      [ "libecs::ConvertTo< ToType, char[_N] >", "classlibecs_1_1ConvertTo_3_01ToType_00_01char[__N]_01_4.html", null ],
      [ "libecs::ConvertTo< ToType, const char[_N] >", "classlibecs_1_1ConvertTo_3_01ToType_00_01const_01char[__N]_01_4.html", null ],
      [ "libecs::ConvertTo< ToType, String >", "classlibecs_1_1ConvertTo_3_01ToType_00_01String_01_4.html", null ],
      [ "libecs::DataPoint", "classlibecs_1_1DataPoint.html", null ],
      [ "libecs::DataPointAggregator", "classlibecs_1_1DataPointAggregator.html", null ],
      [ "libecs::DataPointVector", "classlibecs_1_1DataPointVector.html", null ],
      [ "libemc::DefaultEventChecker", "classlibemc_1_1DefaultEventChecker.html", null ],
      [ "libecs::DeletePtr< T_ >", "structlibecs_1_1DeletePtr.html", null ],
      [ "libecs::DynamicCaster< NEW, GIVEN >", "classlibecs_1_1DynamicCaster.html", null ],
      [ "libecs::DynamicPriorityQueue< Item, IDPolicy >", "classlibecs_1_1DynamicPriorityQueue.html", null ],
      [ "libecs::DataPoint::EarlinessOrdering", "classlibecs_1_1DataPoint_1_1EarlinessOrdering.html", null ],
      [ "libecs::EcsObject", "classlibecs_1_1EcsObject.html", null ],
      [ "libecs::EcsObjectMaker< T_ >", "classlibecs_1_1EcsObjectMaker.html", null ],
      [ "libecs::scripting::EntityResolver", "classlibecs_1_1scripting_1_1EntityResolver.html", null ],
      [ "libecs::EntityType", "classlibecs_1_1EntityType.html", null ],
      [ "libecs::scripting::ErrorReporter", "classlibecs_1_1scripting_1_1ErrorReporter.html", null ],
      [ "libecs::EventBase", "classlibecs_1_1EventBase.html", null ],
      [ "libemc::EventChecker", "classlibemc_1_1EventChecker.html", null ],
      [ "libemc::EventHandler", "classlibemc_1_1EventHandler.html", null ],
      [ "libecs::EventScheduler< Event_ >", "classlibecs_1_1EventScheduler.html", null ],
      [ "libecs::Exception", "classlibecs_1_1Exception.html", null ],
      [ "libecs::scripting::ExpressionCompiler", "classlibecs_1_1scripting_1_1ExpressionCompiler.html", null ],
      [ "libecs::FullID", "classlibecs_1_1FullID.html", null ],
      [ "libecs::VariableReference::FullIDLess", "classlibecs_1_1VariableReference_1_1FullIDLess.html", null ],
      [ "libecs::FullPN", "classlibecs_1_1FullPN.html", null ],
      [ "libecs::Handle", "classlibecs_1_1Handle.html", null ],
      [ "libecs::VolatileIDPolicy::IDIterator", "classlibecs_1_1VolatileIDPolicy_1_1IDIterator.html", null ],
      [ "libecs::scripting::Instruction< Eop_ >", "classlibecs_1_1scripting_1_1Instruction.html", null ],
      [ "libecs::scripting::InstructionBase< Eop_, Toper_ >", "classlibecs_1_1scripting_1_1InstructionBase.html", null ],
      [ "libecs::scripting::InstructionBase< Eop_, NoOperand >", "classlibecs_1_1scripting_1_1InstructionBase_3_01Eop___00_01NoOperand_01_4.html", null ],
      [ "libecs::scripting::InstructionHead", "classlibecs_1_1scripting_1_1InstructionHead.html", null ],
      [ "libecs::Interpolant", "classlibecs_1_1Interpolant.html", null ],
      [ "libecs::LoggerBroker::iterator", "structlibecs_1_1LoggerBroker_1_1iterator.html", null ],
      [ "libecs::LoggerBroker::iterator_base< Tderived_, Tconstness_ >", "structlibecs_1_1LoggerBroker_1_1iterator__base.html", null ],
      [ "libecs::DataPoint::LatenessOrdering", "classlibecs_1_1DataPoint_1_1LatenessOrdering.html", null ],
      [ "less", "classstd_1_1less.html", null ],
      [ "libecs::VariableReference::Less", "classlibecs_1_1VariableReference_1_1Less.html", null ],
      [ "libecs::LexicalCaster< NEW, GIVEN >", "classlibecs_1_1LexicalCaster.html", null ],
      [ "libecs::LoadSaveConcretePropertySlot< T, SlotType_ >", "classlibecs_1_1LoadSaveConcretePropertySlot.html", null ],
      [ "libemc::LocalSimulatorImplementation", "classlibemc_1_1LocalSimulatorImplementation.html", null ],
      [ "libecs::Logger", "classlibecs_1_1Logger.html", null ],
      [ "libecs::LoggerAdapter", "classlibecs_1_1LoggerAdapter.html", null ],
      [ "libecs::LoggerBroker", "classlibecs_1_1LoggerBroker.html", null ],
      [ "libecs::LongDataPoint", "classlibecs_1_1LongDataPoint.html", null ],
      [ "libecs::MethodProxy< CLASS, RET >", "classlibecs_1_1MethodProxy_3_01CLASS_00_01RET_01_4.html", null ],
      [ "libecs::Model", "classlibecs_1_1Model.html", null ],
      [ "libecs::scripting::NoOperand", "classlibecs_1_1scripting_1_1NoOperand.html", null ],
      [ "libecs::NumericCaster< NEW, GIVEN >", "classlibecs_1_1NumericCaster.html", null ],
      [ "libecs::ObjectMethodProxy< RET >", "classlibecs_1_1ObjectMethodProxy_3_01RET_01_4.html", null ],
      [ "libecs::scripting::Opcode2Operand< OPCODE >", "classlibecs_1_1scripting_1_1Opcode2Operand.html", null ],
      [ "libecs::Param< T >", "classlibecs_1_1Param.html", null ],
      [ "libecs::PersistentIDPolicy", "classlibecs_1_1PersistentIDPolicy.html", null ],
      [ "libecs::PhysicalLogger", "classlibecs_1_1PhysicalLogger.html", null ],
      [ "libecs::Logger::Policy", "classlibecs_1_1Logger_1_1Policy.html", null ],
      [ "libecs::Polymorph", "classlibecs_1_1Polymorph.html", null ],
      [ "libecs::PolymorphValue", "classlibecs_1_1PolymorphValue.html", null ],
      [ "libecs::ProcessEvent", "classlibecs_1_1ProcessEvent.html", null ],
      [ "libecs::scripting::PropertyAccess", "classlibecs_1_1scripting_1_1PropertyAccess.html", null ],
      [ "libecs::PropertyAttributes", "classlibecs_1_1PropertyAttributes.html", null ],
      [ "libecs::PropertyInterface< T >", "classlibecs_1_1PropertyInterface.html", null ],
      [ "libecs::PropertyInterfaceBase", "classlibecs_1_1PropertyInterfaceBase.html", null ],
      [ "libecs::PropertySlot< T >", "classlibecs_1_1PropertySlot.html", null ],
      [ "libecs::PropertySlotBase", "classlibecs_1_1PropertySlotBase.html", null ],
      [ "libecs::PropertySlotProxy", "classlibecs_1_1PropertySlotProxy.html", null ],
      [ "libecs::PropertySlotProxyLoggerAdapter", "classlibecs_1_1PropertySlotProxyLoggerAdapter.html", null ],
      [ "libecs::PtrGreater< T >", "structlibecs_1_1PtrGreater.html", null ],
      [ "libecs::PtrLess< T >", "structlibecs_1_1PtrLess.html", null ],
      [ "boost::range_const_iterator< libecs::PolymorphValue::Tuple >", "structboost_1_1range__const__iterator_3_01libecs_1_1PolymorphValue_1_1Tuple_01_4.html", null ],
      [ "boost::range_iterator< libecs::PolymorphValue::Tuple >", "structboost_1_1range__iterator_3_01libecs_1_1PolymorphValue_1_1Tuple_01_4.html", null ],
      [ "libecs::PolymorphValue::RawString", "classlibecs_1_1PolymorphValue_1_1RawString.html", null ],
      [ "libecs::SecondBinder< OP >", "classlibecs_1_1SecondBinder.html", null ],
      [ "libecs::SelectFirst< T_ >", "structlibecs_1_1SelectFirst.html", null ],
      [ "libecs::SelectSecond< T_ >", "structlibecs_1_1SelectSecond.html", null ],
      [ "libemc::Simulator", "classlibemc_1_1Simulator.html", null ],
      [ "libemc::SimulatorImplementation", "classlibemc_1_1SimulatorImplementation.html", null ],
      [ "libecs::StaticCaster< NEW, GIVEN >", "classlibecs_1_1StaticCaster.html", null ],
      [ "libecs::StepperEvent", "classlibecs_1_1StepperEvent.html", null ],
      [ "libecs::SystemPath", "classlibecs_1_1SystemPath.html", null ],
      [ "libecs::PolymorphValue::Tuple", "classlibecs_1_1PolymorphValue_1_1Tuple.html", null ],
      [ "libecs::Type2Type< T >", "structlibecs_1_1Type2Type.html", null ],
      [ "libecs::PropertySlotBase::TypeToTypeCode< T_ >", "structlibecs_1_1PropertySlotBase_1_1TypeToTypeCode.html", null ],
      [ "libecs::PropertySlotBase::TypeToTypeCode< Integer >", "structlibecs_1_1PropertySlotBase_1_1TypeToTypeCode_3_01Integer_01_4.html", null ],
      [ "libecs::PropertySlotBase::TypeToTypeCode< Polymorph >", "structlibecs_1_1PropertySlotBase_1_1TypeToTypeCode_3_01Polymorph_01_4.html", null ],
      [ "libecs::PropertySlotBase::TypeToTypeCode< Real >", "structlibecs_1_1PropertySlotBase_1_1TypeToTypeCode_3_01Real_01_4.html", null ],
      [ "libecs::PropertySlotBase::TypeToTypeCode< String >", "structlibecs_1_1PropertySlotBase_1_1TypeToTypeCode_3_01String_01_4.html", null ],
      [ "libecs::UnaryCompose< Tfun1_, Tfun2_ >", "structlibecs_1_1UnaryCompose.html", null ],
      [ "libecs::UnaryComposeImpl< Tderived_, Tfun1_, Tfun2_, Tretval_ >", "structlibecs_1_1UnaryComposeImpl.html", null ],
      [ "libecs::UnaryComposeImpl< Tderived_, Tfun1_, Tfun2_, void >", "structlibecs_1_1UnaryComposeImpl_3_01Tderived___00_01Tfun1___00_01Tfun2___00_01void_01_4.html", null ],
      [ "Loki::AssocVector< K, V, C, A >::value_compare", "classLoki_1_1AssocVector_1_1value__compare.html", null ],
      [ "libecs::Interpolant::VariablePtrCompare", "classlibecs_1_1Interpolant_1_1VariablePtrCompare.html", null ],
      [ "libecs::VariableReference", "classlibecs_1_1VariableReference.html", null ],
      [ "libecs::scripting::VariableReferenceResolver", "classlibecs_1_1scripting_1_1VariableReferenceResolver.html", null ],
      [ "vector", "classstd_1_1vector.html", null ],
      [ "libecs::scripting::VirtualMachine", "classlibecs_1_1scripting_1_1VirtualMachine.html", null ],
      [ "libecs::VolatileIDPolicy", "classlibecs_1_1VolatileIDPolicy.html", null ],
      [ "libecs::vvector< T >", "classlibecs_1_1vvector.html", null ],
      [ "libecs::vvector_full", "classlibecs_1_1vvector__full.html", null ],
      [ "libecs::vvector_init_error", "classlibecs_1_1vvector__init__error.html", null ],
      [ "libecs::vvector_read_error", "classlibecs_1_1vvector__read__error.html", null ],
      [ "libecs::vvector_write_error", "classlibecs_1_1vvector__write__error.html", null ],
      [ "libecs::vvectorbase", "classlibecs_1_1vvectorbase.html", null ],
      [ "libecs::WarningHandler", "classlibecs_1_1WarningHandler.html", null ]
    ] ],
    [ "Class Index", "classes.html", null ],
    [ "Class Hierarchy", "hierarchy.html", [
      [ "libecs::scripting::Assembler", "classlibecs_1_1scripting_1_1Assembler.html", null ],
      [ "C", "classC.html", [
        [ "Loki::Private::AssocVectorCompare< V, C >", "classLoki_1_1Private_1_1AssocVectorCompare.html", [
          [ "Loki::AssocVector< K, V, C, A >", "classLoki_1_1AssocVector.html", null ]
        ] ],
        [ "Loki::Private::AssocVectorCompare< Value, C >", "classLoki_1_1Private_1_1AssocVectorCompare.html", null ]
      ] ],
      [ "libecs::VariableReference::CoefficientLess", "classlibecs_1_1VariableReference_1_1CoefficientLess.html", null ],
      [ "libecs::ConvertTo< ToType, FromType >", "classlibecs_1_1ConvertTo.html", null ],
      [ "libecs::ConvertTo< String, FromType >", "classlibecs_1_1ConvertTo_3_01String_00_01FromType_01_4.html", null ],
      [ "libecs::ConvertTo< String, Polymorph >", "classlibecs_1_1ConvertTo_3_01String_00_01Polymorph_01_4.html", null ],
      [ "libecs::ConvertTo< String, String >", "classlibecs_1_1ConvertTo_3_01String_00_01String_01_4.html", null ],
      [ "libecs::ConvertTo< Tnew_, Polymorph >", "classlibecs_1_1ConvertTo_3_01Tnew___00_01Polymorph_01_4.html", null ],
      [ "libecs::ConvertTo< ToType, char * >", "classlibecs_1_1ConvertTo_3_01ToType_00_01char_01_5_01_4.html", null ],
      [ "libecs::ConvertTo< ToType, char const * >", "classlibecs_1_1ConvertTo_3_01ToType_00_01char_01const_01_5_01_4.html", null ],
      [ "libecs::ConvertTo< ToType, char[_N] >", "classlibecs_1_1ConvertTo_3_01ToType_00_01char[__N]_01_4.html", null ],
      [ "libecs::ConvertTo< ToType, const char[_N] >", "classlibecs_1_1ConvertTo_3_01ToType_00_01const_01char[__N]_01_4.html", null ],
      [ "libecs::ConvertTo< ToType, String >", "classlibecs_1_1ConvertTo_3_01ToType_00_01String_01_4.html", null ],
      [ "libecs::DataPoint", "classlibecs_1_1DataPoint.html", [
        [ "libecs::LongDataPoint", "classlibecs_1_1LongDataPoint.html", null ]
      ] ],
      [ "libecs::DataPointAggregator", "classlibecs_1_1DataPointAggregator.html", null ],
      [ "libecs::DataPointVector", "classlibecs_1_1DataPointVector.html", null ],
      [ "libecs::DeletePtr< T_ >", "structlibecs_1_1DeletePtr.html", null ],
      [ "libecs::DynamicCaster< NEW, GIVEN >", "classlibecs_1_1DynamicCaster.html", null ],
      [ "libecs::DynamicPriorityQueue< Item, IDPolicy >", "classlibecs_1_1DynamicPriorityQueue.html", null ],
      [ "libecs::DataPoint::EarlinessOrdering", "classlibecs_1_1DataPoint_1_1EarlinessOrdering.html", null ],
      [ "libecs::EcsObject", "classlibecs_1_1EcsObject.html", null ],
      [ "libecs::EcsObjectMaker< T_ >", "classlibecs_1_1EcsObjectMaker.html", null ],
      [ "libecs::scripting::EntityResolver", "classlibecs_1_1scripting_1_1EntityResolver.html", null ],
      [ "libecs::EntityType", "classlibecs_1_1EntityType.html", null ],
      [ "libecs::scripting::ErrorReporter", "classlibecs_1_1scripting_1_1ErrorReporter.html", null ],
      [ "libecs::EventBase", "classlibecs_1_1EventBase.html", [
        [ "libecs::ProcessEvent", "classlibecs_1_1ProcessEvent.html", null ],
        [ "libecs::StepperEvent", "classlibecs_1_1StepperEvent.html", null ]
      ] ],
      [ "libemc::EventChecker", "classlibemc_1_1EventChecker.html", [
        [ "libemc::DefaultEventChecker", "classlibemc_1_1DefaultEventChecker.html", null ]
      ] ],
      [ "libemc::EventHandler", "classlibemc_1_1EventHandler.html", null ],
      [ "libecs::EventScheduler< Event_ >", "classlibecs_1_1EventScheduler.html", null ],
      [ "libecs::Exception", "classlibecs_1_1Exception.html", null ],
      [ "libecs::scripting::ExpressionCompiler", "classlibecs_1_1scripting_1_1ExpressionCompiler.html", null ],
      [ "libecs::FullID", "classlibecs_1_1FullID.html", null ],
      [ "libecs::VariableReference::FullIDLess", "classlibecs_1_1VariableReference_1_1FullIDLess.html", null ],
      [ "libecs::FullPN", "classlibecs_1_1FullPN.html", null ],
      [ "libecs::Handle", "classlibecs_1_1Handle.html", null ],
      [ "libecs::VolatileIDPolicy::IDIterator", "classlibecs_1_1VolatileIDPolicy_1_1IDIterator.html", null ],
      [ "libecs::scripting::InstructionHead", "classlibecs_1_1scripting_1_1InstructionHead.html", [
        [ "libecs::scripting::InstructionBase< Eop_, Opcode2Operand< Eop_ >::type >", "classlibecs_1_1scripting_1_1InstructionBase.html", [
          [ "libecs::scripting::Instruction< Eop_ >", "classlibecs_1_1scripting_1_1Instruction.html", null ]
        ] ],
        [ "libecs::scripting::InstructionBase< Eop_, Toper_ >", "classlibecs_1_1scripting_1_1InstructionBase.html", null ],
        [ "libecs::scripting::InstructionBase< Eop_, NoOperand >", "classlibecs_1_1scripting_1_1InstructionBase_3_01Eop___00_01NoOperand_01_4.html", null ]
      ] ],
      [ "libecs::Interpolant", "classlibecs_1_1Interpolant.html", null ],
      [ "libecs::LoggerBroker::iterator_base< Tderived_, Tconstness_ >", "structlibecs_1_1LoggerBroker_1_1iterator__base.html", null ],
      [ "libecs::LoggerBroker::iterator_base< const_iterator, boost::mpl::bool_< true > >", "structlibecs_1_1LoggerBroker_1_1iterator__base.html", [
        [ "libecs::LoggerBroker::const_iterator", "structlibecs_1_1LoggerBroker_1_1const__iterator.html", null ]
      ] ],
      [ "libecs::LoggerBroker::iterator_base< iterator, boost::mpl::bool_< false > >", "structlibecs_1_1LoggerBroker_1_1iterator__base.html", [
        [ "libecs::LoggerBroker::iterator", "structlibecs_1_1LoggerBroker_1_1iterator.html", null ]
      ] ],
      [ "libecs::DataPoint::LatenessOrdering", "classlibecs_1_1DataPoint_1_1LatenessOrdering.html", null ],
      [ "less", "classstd_1_1less.html", null ],
      [ "libecs::VariableReference::Less", "classlibecs_1_1VariableReference_1_1Less.html", null ],
      [ "libecs::LexicalCaster< NEW, GIVEN >", "classlibecs_1_1LexicalCaster.html", null ],
      [ "libecs::Logger", "classlibecs_1_1Logger.html", null ],
      [ "libecs::LoggerAdapter", "classlibecs_1_1LoggerAdapter.html", [
        [ "libecs::PropertySlotProxyLoggerAdapter", "classlibecs_1_1PropertySlotProxyLoggerAdapter.html", null ]
      ] ],
      [ "libecs::LoggerBroker", "classlibecs_1_1LoggerBroker.html", null ],
      [ "libecs::MethodProxy< CLASS, RET >", "classlibecs_1_1MethodProxy_3_01CLASS_00_01RET_01_4.html", null ],
      [ "libecs::Model", "classlibecs_1_1Model.html", null ],
      [ "libecs::scripting::NoOperand", "classlibecs_1_1scripting_1_1NoOperand.html", null ],
      [ "libecs::NumericCaster< NEW, GIVEN >", "classlibecs_1_1NumericCaster.html", null ],
      [ "libecs::ObjectMethodProxy< RET >", "classlibecs_1_1ObjectMethodProxy_3_01RET_01_4.html", null ],
      [ "libecs::scripting::Opcode2Operand< OPCODE >", "classlibecs_1_1scripting_1_1Opcode2Operand.html", null ],
      [ "libecs::Param< T >", "classlibecs_1_1Param.html", null ],
      [ "libecs::PersistentIDPolicy", "classlibecs_1_1PersistentIDPolicy.html", null ],
      [ "libecs::PhysicalLogger", "classlibecs_1_1PhysicalLogger.html", null ],
      [ "libecs::Logger::Policy", "classlibecs_1_1Logger_1_1Policy.html", null ],
      [ "libecs::Polymorph", "classlibecs_1_1Polymorph.html", null ],
      [ "libecs::PolymorphValue", "classlibecs_1_1PolymorphValue.html", null ],
      [ "libecs::scripting::PropertyAccess", "classlibecs_1_1scripting_1_1PropertyAccess.html", null ],
      [ "libecs::PropertyAttributes", "classlibecs_1_1PropertyAttributes.html", null ],
      [ "libecs::PropertyInterfaceBase", "classlibecs_1_1PropertyInterfaceBase.html", [
        [ "libecs::PropertyInterface< T >", "classlibecs_1_1PropertyInterface.html", null ]
      ] ],
      [ "libecs::PropertySlotBase", "classlibecs_1_1PropertySlotBase.html", [
        [ "libecs::PropertySlot< T >", "classlibecs_1_1PropertySlot.html", [
          [ "libecs::ConcretePropertySlot< T, SlotType_ >", "classlibecs_1_1ConcretePropertySlot.html", [
            [ "libecs::LoadSaveConcretePropertySlot< T, SlotType_ >", "classlibecs_1_1LoadSaveConcretePropertySlot.html", null ]
          ] ]
        ] ]
      ] ],
      [ "libecs::PropertySlotProxy", "classlibecs_1_1PropertySlotProxy.html", [
        [ "libecs::ConcretePropertySlotProxy< T >", "classlibecs_1_1ConcretePropertySlotProxy.html", null ]
      ] ],
      [ "libecs::PtrGreater< T >", "structlibecs_1_1PtrGreater.html", null ],
      [ "libecs::PtrLess< T >", "structlibecs_1_1PtrLess.html", null ],
      [ "boost::range_const_iterator< libecs::PolymorphValue::Tuple >", "structboost_1_1range__const__iterator_3_01libecs_1_1PolymorphValue_1_1Tuple_01_4.html", null ],
      [ "boost::range_iterator< libecs::PolymorphValue::Tuple >", "structboost_1_1range__iterator_3_01libecs_1_1PolymorphValue_1_1Tuple_01_4.html", null ],
      [ "libecs::PolymorphValue::RawString", "classlibecs_1_1PolymorphValue_1_1RawString.html", null ],
      [ "libecs::SecondBinder< OP >", "classlibecs_1_1SecondBinder.html", null ],
      [ "libecs::SelectFirst< T_ >", "structlibecs_1_1SelectFirst.html", null ],
      [ "libecs::SelectSecond< T_ >", "structlibecs_1_1SelectSecond.html", null ],
      [ "libemc::Simulator", "classlibemc_1_1Simulator.html", null ],
      [ "libemc::SimulatorImplementation", "classlibemc_1_1SimulatorImplementation.html", [
        [ "libemc::LocalSimulatorImplementation", "classlibemc_1_1LocalSimulatorImplementation.html", null ]
      ] ],
      [ "libecs::StaticCaster< NEW, GIVEN >", "classlibecs_1_1StaticCaster.html", null ],
      [ "libecs::SystemPath", "classlibecs_1_1SystemPath.html", null ],
      [ "libecs::PolymorphValue::Tuple", "classlibecs_1_1PolymorphValue_1_1Tuple.html", null ],
      [ "libecs::Type2Type< T >", "structlibecs_1_1Type2Type.html", null ],
      [ "libecs::PropertySlotBase::TypeToTypeCode< T_ >", "structlibecs_1_1PropertySlotBase_1_1TypeToTypeCode.html", null ],
      [ "libecs::PropertySlotBase::TypeToTypeCode< Integer >", "structlibecs_1_1PropertySlotBase_1_1TypeToTypeCode_3_01Integer_01_4.html", null ],
      [ "libecs::PropertySlotBase::TypeToTypeCode< Polymorph >", "structlibecs_1_1PropertySlotBase_1_1TypeToTypeCode_3_01Polymorph_01_4.html", null ],
      [ "libecs::PropertySlotBase::TypeToTypeCode< Real >", "structlibecs_1_1PropertySlotBase_1_1TypeToTypeCode_3_01Real_01_4.html", null ],
      [ "libecs::PropertySlotBase::TypeToTypeCode< String >", "structlibecs_1_1PropertySlotBase_1_1TypeToTypeCode_3_01String_01_4.html", null ],
      [ "libecs::UnaryComposeImpl< Tderived_, Tfun1_, Tfun2_, Tretval_ >", "structlibecs_1_1UnaryComposeImpl.html", null ],
      [ "libecs::UnaryComposeImpl< Tderived_, Tfun1_, Tfun2_, void >", "structlibecs_1_1UnaryComposeImpl_3_01Tderived___00_01Tfun1___00_01Tfun2___00_01void_01_4.html", null ],
      [ "libecs::UnaryComposeImpl< UnaryCompose< Tfun1_, Tfun2_ >, Tfun1_, Tfun2_ >", "structlibecs_1_1UnaryComposeImpl.html", [
        [ "libecs::UnaryCompose< Tfun1_, Tfun2_ >", "structlibecs_1_1UnaryCompose.html", null ]
      ] ],
      [ "Loki::AssocVector< K, V, C, A >::value_compare", "classLoki_1_1AssocVector_1_1value__compare.html", null ],
      [ "libecs::Interpolant::VariablePtrCompare", "classlibecs_1_1Interpolant_1_1VariablePtrCompare.html", null ],
      [ "libecs::VariableReference", "classlibecs_1_1VariableReference.html", null ],
      [ "libecs::scripting::VariableReferenceResolver", "classlibecs_1_1scripting_1_1VariableReferenceResolver.html", null ],
      [ "vector", "classstd_1_1vector.html", [
        [ "Loki::AssocVector< K, V, C, A >", "classLoki_1_1AssocVector.html", null ]
      ] ],
      [ "libecs::scripting::VirtualMachine", "classlibecs_1_1scripting_1_1VirtualMachine.html", null ],
      [ "libecs::VolatileIDPolicy", "classlibecs_1_1VolatileIDPolicy.html", null ],
      [ "libecs::vvector_full", "classlibecs_1_1vvector__full.html", null ],
      [ "libecs::vvector_init_error", "classlibecs_1_1vvector__init__error.html", null ],
      [ "libecs::vvector_read_error", "classlibecs_1_1vvector__read__error.html", null ],
      [ "libecs::vvector_write_error", "classlibecs_1_1vvector__write__error.html", null ],
      [ "libecs::vvectorbase", "classlibecs_1_1vvectorbase.html", [
        [ "libecs::vvector< T >", "classlibecs_1_1vvector.html", null ]
      ] ],
      [ "libecs::WarningHandler", "classlibecs_1_1WarningHandler.html", null ]
    ] ],
    [ "Class Members", "functions.html", null ],
    [ "Namespace List", "namespaces.html", [
      [ "libecs", "namespacelibecs.html", null ]
    ] ],
    [ "Namespace Members", "namespacemembers.html", null ],
    [ "File List", "files.html", [
      [ "AdaptiveDifferentialStepper.hpp", null, null ],
      [ "Assembler.hpp", null, null ],
      [ "AssocVector.h", null, null ],
      [ "ContinuousProcess.hpp", null, null ],
      [ "convertTo.hpp", null, null ],
      [ "DataPoint.hpp", null, null ],
      [ "DataPointVector.hpp", null, null ],
      [ "Defs.hpp", null, null ],
      [ "DifferentialStepper.hpp", null, null ],
      [ "DiscreteEventStepper.hpp", null, null ],
      [ "DiscreteTimeStepper.hpp", null, null ],
      [ "DynamicPriorityQueue.hpp", null, null ],
      [ "EcsObject.hpp", null, null ],
      [ "EcsObjectMaker.hpp", null, null ],
      [ "Entity.hpp", null, null ],
      [ "EntityType.hpp", null, null ],
      [ "EventScheduler.hpp", null, null ],
      [ "Exceptions.hpp", null, null ],
      [ "ExpressionCompiler.hpp", null, null ],
      [ "FullID.hpp", null, null ],
      [ "Handle.hpp", null, null ],
      [ "Instruction.hpp", null, null ],
      [ "Interpolant.hpp", null, null ],
      [ "libecs.hpp", null, null ],
      [ "libemc.hpp", null, null ],
      [ "LocalSimulatorImplementation.hpp", null, null ],
      [ "Logger.hpp", null, null ],
      [ "LoggerAdapter.hpp", null, null ],
      [ "LoggerBroker.hpp", null, null ],
      [ "MethodProxy.hpp", null, null ],
      [ "Model.hpp", null, null ],
      [ "osif.h", null, null ],
      [ "PassiveStepper.hpp", null, null ],
      [ "PhysicalLogger.hpp", null, null ],
      [ "Polymorph.hpp", null, null ],
      [ "Process.hpp", null, null ],
      [ "ProcessEvent.hpp", null, null ],
      [ "PropertyAttributes.hpp", null, null ],
      [ "PropertyInterface.hpp", null, null ],
      [ "PropertySlot.hpp", null, null ],
      [ "PropertySlotProxy.hpp", null, null ],
      [ "PropertySlotProxyLoggerAdapter.hpp", null, null ],
      [ "RealMath.hpp", null, null ],
      [ "Simulator.hpp", null, null ],
      [ "SimulatorImplementation.hpp", null, null ],
      [ "Stepper.hpp", null, null ],
      [ "StepperEvent.hpp", null, null ],
      [ "System.hpp", null, null ],
      [ "SystemStepper.hpp", null, null ],
      [ "Util.hpp", null, null ],
      [ "Variable.hpp", null, null ],
      [ "VariableReference.hpp", null, null ],
      [ "VirtualMachine.hpp", null, null ],
      [ "VVector.h", null, null ]
    ] ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

